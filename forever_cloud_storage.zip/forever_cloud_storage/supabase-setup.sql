-- FOREVER CLOUD setup for Supabase
-- Run this whole script in Supabase Dashboard > SQL Editor.
-- Creates a PRIVATE bucket and policies that isolate every user's folder.

insert into storage.buckets (id, name, public, file_size_limit)
values ('user-files', 'user-files', false, 52428800)
on conflict (id) do update set public = false, file_size_limit = 52428800;

-- Users can list only objects in their own folder (folder name = auth.uid()).
create policy "Users can list their own files"
on storage.objects for select
to authenticated
using (
  bucket_id = 'user-files'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can upload into their own folder"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'user-files'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can update their own files"
on storage.objects for update
to authenticated
using (
  bucket_id = 'user-files'
  and (storage.foldername(name))[1] = auth.uid()::text
)
with check (
  bucket_id = 'user-files'
  and (storage.foldername(name))[1] = auth.uid()::text
);

create policy "Users can delete their own files"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'user-files'
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Note: If rerunning this script, Supabase may report that a policy already exists.
-- In that case, remove the old policy in Dashboard > Storage > Policies or drop it
-- before recreating. Do not make the bucket public.
